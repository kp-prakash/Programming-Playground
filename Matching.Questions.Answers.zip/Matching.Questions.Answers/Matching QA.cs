using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

public static class LanguageUtils
{
    public static List<string> StopWords = new List<string> {
            "a", "about", "above", "across", "after",
            "again", "against", "all", "almost", "alone",
            "along", "already", "also", "although", "always",
            "among", "an", "and", "another", "any",
            "anybody", "anyone", "anything", "anywhere", "are",
            "area", "areas", "around", "as", "ask",
            "asked", "asking", "asks", "at", "away",
            "b", "back", "backed", "backing", "backs",
            "be", "because", "became", "become", "becomes",
            "been", "before", "began", "behind", "being",
            "beings", "best", "better", "between", "big",
            "both", "but", "by", "c", "came",
            "can", "cannot", "case", "cases", "certain",
            "certainly", "clear", "clearly", "come", "could",
            "d", "did", "differ", "different", "differently",
            "do", "does", "done", "down", "downed",
            "downing", "downs", "during", "e", "each",
            "early", "either", "end", "ended", "ending",
            "ends", "enough", "even", "evenly", "ever",
            "every", "everybody", "everyone", "everything", "everywhere",
            "f", "face", "faces", "fact", "facts",
            "far", "felt", "few", "find", "finds",
            "first", "for", "four", "from", "full",
            "fully", "further", "furthered", "furthering", "furthers",
            "g", "gave", "general", "generally", "get",
            "gets", "give", "given", "gives", "go",
            "going", "good", "goods", "got", "great",
            "greater", "greatest", "group", "grouped", "grouping",
            "groups", "h", "had", "has", "have",
            "having", "he", "her", "herself", "here",
            "high", "higher", "highest", "him", "himself",
            "his", "how", "however", "i", "if",
            "important", "in", "interest", "interested", "interesting",
            "interests", "into", "is", "it", "its",
            "itself", "j", "just", "k", "keep",
            "keeps", "kind", "knew", "know", "known",
            "knows", "l", "large", "largely", "last",
            "later", "latest", "least", "less", "let",
            "lets", "like", "likely", "long", "longer",
            "longest", "m", "made", "make", "making",
            "man", "many", "may", "me", "member",
            "members", "men", "might", "more", "most",
            "mostly", "mr", "mrs", "much", "must",
            "my", "myself", "n", "necessary", "need",
            "needed", "needing", "needs", "never", "new",
            "newer", "newest", "next", "no", "non",
            "not", "nobody", "noone", "nothing", "now",
            "nowhere", "number", "numbered", "numbering", "numbers",
            "of", "off", "often", "old",
            "older", "oldest", "on", "once", "one",
            "only", "open", "opened", "opening", "opens",
            "or", "order", "ordered", "ordering", "orders",
            "other", "others", "our", "out", "over",
            "p", "part", "parted", "parting", "parts",
            "per", "perhaps", "place", "places", "point",
            "pointed", "pointing", "points", "possible", "present",
            "presented", "presenting", "presents", "problem", "problems",
            "put", "puts", "q", "quite", "r",
            "rather", "really", "right", "room", "rooms",
            "s", "said", "same", "saw", "say",
            "says", "second", "seconds", "see", "seem",
            "seemed", "seeming", "seems", "sees", "several",
            "shall", "she", "should", "show", "showed",
            "showing", "shows", "side", "sides", "since",
            "small", "smaller", "smallest", "so", "some",
            "somebody", "someone", "something", "somewhere", "state",
            "states", "still", "such", "sure", "t",
            "take", "taken", "than", "that", "the",
            "their", "them", "then", "there", "therefore",
            "these", "they", "thing", "things", "think",
            "thinks", "this", "those", "though", "thought",
            "thoughts", "three", "through", "thus", "to",
            "today", "together", "too", "took", "toward",
            "turn", "turned", "turning", "turns", "two",
            "u", "under", "until", "up", "upon",
            "us", "use", "uses", "used", "v",
            "very", "w", "want", "wanted", "wanting",
            "wants", "was", "way", "ways", "we",
            "well", "wells", "went", "were", "what",
            "when", "where", "whether", "which", "while",
            "who", "whole", "whose", "why", "will",
            "with", "within", "without", "work", "worked",
            "working", "works", "would", "x", "y",
            "year", "years", "yet", "you", "young",
            "younger", "youngest", "your", "yours", "z"
        };
}

internal class Solution
{
    private const int numberOfQuestions = 5;

    public static string[] Answers { get; private set; }

    public static string Paragraph { get; private set; }

    public static List<string> Questions { get; private set; }

    public static string[] Sentences { get; private set; }

    public static void Main(string[] args)
    {
        Paragraph = Console.ReadLine();
        Questions = new List<string>(5);
        for (int i = 0; i < 5; i++)
        {
            Questions.Add(Console.ReadLine());
        }
        Answers = Console.ReadLine().Split(';');

        var clonedCopyOfQuestions = new List<string>();
        foreach (var question in Questions)
        {
            clonedCopyOfQuestions.Add(question);
        }

        Sentences = GetSentences(Paragraph);

        Dictionary<string, string> mappedAnswersAndQuestions = Match();
        PrintAnswers(clonedCopyOfQuestions, mappedAnswersAndQuestions);
        Console.ReadLine();
    }

    public static Dictionary<string, string> Match()
    {
        Dictionary<string, List<string>> answersAndMatchingSentences = DetermineSentencesContainingAnswer();
        // Sort the answersAndMatchingSentences by least number of matching sentences.
        answersAndMatchingSentences = SortByNumberOfElements(answersAndMatchingSentences);
        Dictionary<string, string> matchedAnswersAndQuestions = DetermineQuestionAndAnswer(answersAndMatchingSentences);
        return matchedAnswersAndQuestions;
    }

    private static Dictionary<string, string> DetermineQuestionAndAnswer(Dictionary<string, List<string>> answersAndMatchingSentences)
    {
        Dictionary<string, string> matchedAnswersAndQuestions = new Dictionary<string, string>();
        foreach (var answer in answersAndMatchingSentences.Keys)
        {
            matchedAnswersAndQuestions[answer] = GetBestPossibleQuestion(answersAndMatchingSentences[answer]);
        }
        return matchedAnswersAndQuestions;
    }

    private static Dictionary<string, List<string>> DetermineSentencesContainingAnswer()
    {
        Dictionary<string, List<string>> answersAndMatchingSentences = new Dictionary<string, List<string>>();
        foreach (var answer in Answers)
        {
            List<string> sentencesContainingAnswer = GetMatchingSentencesContainingAnswer(answer);
            answersAndMatchingSentences[answer] = sentencesContainingAnswer;
        }
        return answersAndMatchingSentences;
    }

    private static string GetBestPossibleQuestion(List<string> sentencesContainingAnswer)
    {
        // NOTES -> SELF: If count is more than one, we need to process both the sentences and choose the question with best pattern match.
        // Since answer is a substring of sentences in the passage, the probability is slightly less, but this case of more than
        // one matching sentence per answer cannot be completely ruled out.
        Dictionary<int, int> bestPossibleMatches = new Dictionary<int, int>();

        foreach (var sentence in sentencesContainingAnswer)
        {
            string[] keywordsInSentence = RemoveStopWords(sentence);
            Dictionary<int, int> possibleMatches = GetPossibleMatches(keywordsInSentence);

            // Update best possible match
            foreach (var key in possibleMatches.Keys)
            {
                var value = possibleMatches[key];
                if (!bestPossibleMatches.ContainsKey(key) || value > bestPossibleMatches[key])
                {
                    bestPossibleMatches[key] = value;
                }
            }
        }

        var bestQuestionIndex = bestPossibleMatches.Aggregate((l, r) => l.Value > r.Value ? l : r).Key;
        string question = Questions[bestQuestionIndex];
        // Remove as this question is chosen!
        Questions.RemoveAt(bestQuestionIndex);
        return question;
    }

    private static List<string> GetMatchingSentencesContainingAnswer(string answer)
    {
        var matchingSentences = Sentences.Where(sentense => sentense.Contains(answer)).ToList();

        #region ONLY FOR TROUBLESHOOTING NUMBER OF MATCHES

        //Console.WriteLine("Answer: {0}", answer);
        //Console.WriteLine("MATCH: {0}", matchingSentences.Count());
        //foreach (var matchingSentence in matchingSentences)
        //{
        //    Console.WriteLine("MATCH: {0}", matchingSentence);
        //}

        #endregion ONLY FOR TROUBLESHOOTING NUMBER OF MATCHES

        return matchingSentences;
    }

    private static int GetNumberofMatchingKeywords(string[] keywordsInSentence, string[] keywordsInQuestion)
    {
        int count = 0;
        // Check if there is partial match between keywords!
        for (int i = 0; i < keywordsInQuestion.Length; i++)
        {
            for (int j = 0; j < keywordsInSentence.Length; j++)
            {
                if (keywordsInQuestion[i].Contains(keywordsInSentence[j])
                    || keywordsInSentence[j].Contains(keywordsInQuestion[i]))
                {
                    count++;
                }
            }
        }

        return count;
    }

    private static Dictionary<int, int> GetPossibleMatches(string[] keywordsInSentence)
    {
        Dictionary<int, int> possibleMatches = new Dictionary<int, int>();
        for (int i = 0; i < Questions.Count; i++)
        {
            string question = Questions[i];
            string[] keywordsInQuestion = RemoveStopWords(question);
            int numberOfMatches = GetNumberofMatchingKeywords(keywordsInSentence, keywordsInQuestion);
            possibleMatches[i] = numberOfMatches;
        }

        return possibleMatches;
    }

    private static string[] GetSentences(string paragraph)
    {
        string[] sentences = paragraph.Split(new char[] { '?', '!', '.' }, StringSplitOptions.RemoveEmptyEntries);
        return sentences;
    }

    private static void PrintAnswers(IList<string> questions, Dictionary<string, string> mappedAnswersAndQuestions)
    {
        Dictionary<string, string> questionAndAnswers = mappedAnswersAndQuestions
                                                        .ToLookup(kvp => kvp.Value)
                                                        .ToDictionary(item => item.Key, g => g.First().Key); // Handle duplicates
        foreach (var key in questions)
        {
            Console.WriteLine(questionAndAnswers[key]);
        }
    }

    private static string[] RemoveStopWords(string sentence)
    {
        string[] words = sentence.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        string[] keywords = words.Where(word => !LanguageUtils.StopWords.Contains(word)).ToArray();
        return keywords;
    }

    private static Dictionary<T, List<T>> SortByNumberOfElements<T>(Dictionary<T, List<T>> input)
    {
        var result = new Dictionary<T, List<T>>();
        var sortedInput = from pair in input
                          orderby pair.Value.Count ascending
                          select pair;

        foreach (var keyValuePair in sortedInput)
        {
            result[keyValuePair.Key] = keyValuePair.Value;
        }

        return result;
    }
}
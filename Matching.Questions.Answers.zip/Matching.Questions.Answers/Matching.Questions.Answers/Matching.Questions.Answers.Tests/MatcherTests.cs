﻿namespace Matching.Questions.Answers.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using FluentAssertions;
    using Xunit;

    /// <summary>
    /// Tests for matcher.
    /// </summary>
    public class MatcherTests
    {
        /// <summary>
        /// Initializings the matcher with valid data returns valid instance.
        /// </summary>
        [Fact]
        public void Initializing_Matcher_with_valid_data_returns_valid_instance()
        {
            var matcher = new Matcher(TestData.SampleParagraph1, TestData.GetQuestions1(), TestData.AnswersForAllQuestions1);
            matcher.Questions.Count.Should().Be(5);
            matcher.Answers.Length.Should().Be(5);
            matcher.Paragraph.Should().NotBe(string.Empty);
            matcher.Sentences.All(s => !string.IsNullOrWhiteSpace(s));
        }

        /// <summary>
        /// Matcher matches the questions and answer correctly for given sample 1.
        /// </summary>
        [Fact]
        public void Matcher_matches_the_questions_and_answer_correctly_for_given_sample1()
        {
            var matcher = new Matcher(TestData.SampleParagraph1, TestData.GetQuestions1(), TestData.AnswersForAllQuestions1);
            var expectedResults = TestData.GetResults1();
            var result = matcher.Match();
            result.Count.Should().Be(expectedResults.Count);
            foreach (var key in expectedResults.Keys)
            {
                result[key].Should().Be(expectedResults[key]);
            }
        }

        /// <summary>
        /// Matcher matches the questions and answer correctly for given sample 2.
        /// </summary>
        [Fact]
        public void Matcher_matches_the_questions_and_answer_correctly_for_given_sample2()
        {
            var matcher = new Matcher(TestData.SampleParagraph2, TestData.GetQuestions2(), TestData.AnswersForAllQuestions2);
            var expectedResults = TestData.GetResults2();
            var result = matcher.Match();
            result.Count.Should().Be(expectedResults.Count);
            foreach (var key in expectedResults.Keys)
            {
                result[key].Should().Be(expectedResults[key]);
            }
        }

        [Fact]
        /// <summary>
        /// Matcher matches the questions and answer correctly for given sample 3.
        /// </summary>
        public void Matcher_matches_the_questions_and_answer_correctly_for_given_sample3()
        {
            var matcher = new Matcher(TestData.SampleParagraph3, TestData.GetQuestions3(), TestData.AnswersForAllQuestions3);
            var expectedResults = TestData.GetResults3();
            var result = matcher.Match();
            result.Count.Should().Be(expectedResults.Count);
            foreach (var key in expectedResults.Keys)
            {
                result[key].Should().Be(expectedResults[key]);
            }
        }

        [Fact]
        /// <summary>
        /// Matcher matches the questions and answer correctly for given sample 4.
        /// </summary>
        public void Matcher_matches_the_questions_and_answer_correctly_for_given_sample4()
        {
            var matcher = new Matcher(TestData.SampleParagraph4, TestData.GetQuestions4(), TestData.AnswersForAllQuestions4);
            var expectedResults = TestData.GetResults4();
            var result = matcher.Match();
            result.Count.Should().Be(expectedResults.Count);
            foreach (var key in expectedResults.Keys)
            {
                result[key].Should().Be(expectedResults[key]);
            }
        }

        [Fact]
        /// <summary>
        /// Matcher matches the questions and answer correctly for given sample 5.
        /// </summary>
        public void Matcher_matches_the_questions_and_answer_correctly_for_given_sample5()
        {
            var matcher = new Matcher(TestData.SampleParagraph5, TestData.GetQuestions5(), TestData.AnswersForAllQuestions5);
            var expectedResults = TestData.GetResults5();
            var result = matcher.Match();
            result.Count.Should().Be(expectedResults.Count);
            foreach (var key in expectedResults.Keys)
            {
                result[key].Should().Be(expectedResults[key]);
            }
        }

        [Fact]
        /// <summary>
        /// Trying to initialize Matcher with empty paragraph returns exception.
        /// </summary>
        public void Trying_to_initialize_Matcher_with_empty_paragraph_returns_exception()
        {
            Action action = () =>
            {
                var matcher = new Matcher(string.Empty, new List<string>(), string.Empty);
            };

            action.ShouldThrow<ArgumentNullException>();
        }

        /// <summary>
        /// Trying to initialize Matcher with no answers returns exception.
        /// </summary>
        [Fact]
        public void Trying_to_initialize_Matcher_with_no_answers_returns_exception()
        {
            Action action = () =>
            {
                var matcher = new Matcher("This is a sample paragraph",
                    new List<string> {
                        "What is your name?",
                        "How are you?"
                    },
                    string.Empty);
            };

            action.ShouldThrow<ArgumentNullException>();
        }

        /// <summary>
        /// Trying to initialize Matcher with no questions returns exception.
        /// </summary>
        [Fact]
        public void Trying_to_initialize_Matcher_with_no_questions_returns_exception()
        {
            Action action = () =>
            {
                var matcher = new Matcher("This is a sample paragraph", null, string.Empty);
            };

            action.ShouldThrow<ArgumentNullException>();
        }

        /// <summary>
        /// Trying to initialize Matcher with null object for questions returns exception.
        /// </summary>
        [Fact]
        public void Trying_to_initialize_Matcher_with_null_object_for_questions_returns_exception()
        {
            Action action = () =>
            {
                var matcher = new Matcher("This is a sample paragraph", new List<string>(), string.Empty);
            };

            action.ShouldThrow<ArgumentNullException>();
        }
    }
}
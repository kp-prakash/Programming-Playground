﻿namespace Matching.Questions.Answers.Tests
{
    using System.Collections.Generic;

    public static class TestData
    {
        public static string AnswersForAllQuestions1 = "subgenus Hippotigris;the plains zebra, the Grevy's zebra and the mountain zebra;horses and donkeys;aims to breed zebras that are phenotypically similar to the quagga;Grevy's zebra and the mountain zebra";
        public static string AnswersForAllQuestions2 = "Two-thirds;after the Roman withdrawal from Britain in the 5th century;the growth of socialism and the Labour Party;1925;the public sector, light and service industries and tourism";
        public static string AnswersForAllQuestions3 = "due to the vivid blue-painted houses around the Mehrangarh Fort;Jodhpur;for the bright, sunny weather it enjoys all the year round;Abhiras (Ahirs);5 November 1556";
        public static string AnswersForAllQuestions4 = "the danger of nuclear weapons;more than 300 scientific papers;principle of relativity could also be extended to gravitational fields;1917;Institute for Advanced Study in Princeton";
        public static string AnswersForAllQuestions5 = "Common Kingfisher;by swooping down from a perch;Alcedines;Coraciiformes;Several fossil birds";

        public static string SampleParagraph1 = "Zebras are several species of African equids (horse family) united by their distinctive black and white stripes. Their stripes come in different patterns, unique to each individual. They are generally social animals that live in small harems to large herds. Unlike their closest relatives, horses and donkeys, zebras have never been truly domesticated. There are three species of zebras: the plains zebra, the Grevy's zebra and the mountain zebra. The plains zebra and the mountain zebra belong to the subgenus Hippotigris, but Grevy's zebra is the sole species of subgenus Dolichohippus. The latter resembles an ass, to which it is closely related, while the former two are more horse-like. All three belong to the genus Equus, along with other living equids. The unique stripes of zebras make them one of the animals most familiar to people. They occur in a variety of habitats, such as grasslands, savannas, woodlands, thorny scrublands, mountains, and coastal hills. However, various anthropogenic factors have had a severe impact on zebra populations, in particular hunting for skins and habitat destruction. Grevy's zebra and the mountain zebra are endangered. While plains zebras are much more plentiful, one subspecies, the quagga, became extinct in the late 19th century though there is currently a plan, called the Quagga Project, that aims to breed zebras that are phenotypically similar to the quagga in a process called breeding back.";
        public static string SampleParagraph2 = "Welsh national identity emerged among the Celtic Britons after the Roman withdrawal from Britain in the 5th century, and Wales is regarded as one of the modern Celtic nations. Llywelyn ap Gruffydd's death in 1282 marked the completion of Edward I of England's conquest of Wales, though Owain Glyndŵr briefly restored independence to what was to become modern Wales, in the early 15th century. The whole of Wales was annexed by England and incorporated within the English legal system, under the Laws in Wales Acts 1535–1542. Distinctive Welsh politics developed in the 19th century. Welsh Liberalism, exemplified in the early 20th century by Lloyd George, was displaced by the growth of socialism and the Labour Party. Welsh national feeling grew over the century; Plaid Cymru was formed in 1925 and the Welsh Language Society in 1962. Established under the Government of Wales Act 1998, the National Assembly for Wales holds responsibility for a range of devolved policy matters. At the dawn of the Industrial Revolution, development of the mining and metallurgical industries transformed the country from an agricultural society into an industrial nation; the South Wales coalfield's exploitation caused a rapid expansion of Wales' population. Two-thirds of the population live in south Wales, mainly in and around Cardiff (the capital), Swansea and Newport, and in the nearby valleys. Now that the country's traditional extractive and heavy industries have either gone or are in decline, Wales' economy depends on the public sector, light and service industries and tourism. Wales' 2010 Gross Value Added (GVA) was £45.5 billion (£15,145 per head); 74.0 per cent of the average for the UK total, the lowest GVA per head in Britain.";
        public static string SampleParagraph3 = "Jodhpur is the second largest city in the Indian state of Rajasthan. After its population crossed a million, it has been declared as the second 'Metropolitan City' of Rajasthan. It was formerly the seat of a princely state of the same name, the capital of the kingdom known as Marwar. Jodhpur is a popular tourist destination, featuring many palaces, forts and temples, set in the stark landscape of the Thar desert. The city is known as the \"Sun City\" for the bright, sunny weather it enjoys all the year round. It is also referred to as the \"Blue City\" due to the vivid blue-painted houses around the Mehrangarh Fort. The old city circles the fort and is bounded by a wall with several gates. However, the city has expanded greatly outside the wall over the past several decades. Jodhpur lies near the geographic centre of Rajasthan state, which makes it a convenient base for travel in a region much frequented by tourists. According to Rajasthan district Gazetteers of Jodhpur and the Hindu epic Ramayana (composed up to 4th century AD), Abhiras (Ahirs) were the original inhabitants of Jodhpur and later Aryans spread to this region. Jodhpur was also part of the Gurjara – Pratihara empire and until 1100 CE was ruled by a powerful Bargujar King. Jodhpur was founded in 1459 by Rao Jodha, a Rajput chief of the Rathore clan. Jodha succeeded in conquering the surrounding territory and thus founded a state which came to be known as Marwar. As Jodha hailed from the nearby town of Mandore, that town initially served as the capital of this state; however, Jodhpur soon took over that role, even during the lifetime of Jodha. The city was located on the strategic road linking Delhi to Gujarat. This enabled it to profit from a flourishing trade in opium, copper, silk, sandals, date palms and coffee. In between 1540 to 1556, Afghans were in control of most of North India. Rajasthan born Samrat Hem Chandra Vikramaditya, popularly called Hemu, who started his career as a supplier of various types of merchandise to Sher Shah Suri empire, held various positions in capital Delhi as 'Incharge of Food Affairs', 'Minister of Internal Security', 'Prime Minister-cum-Chief of Army' with Islam Shah Suri and Adil Shah, who ruled north India from Punjab to Bengal at that point in time. Hemu, who took as the military commander of Afghan army in 1553, crushed the first rebellion, killing the Governor of Ajmer province Juneid Khan and appointed his own Governor in Rajasthan. Hem Chandra won several battles (22) throughout North India against Afghan rebels and twice against Akbar at Agra and Delhi, before his coronation at Purana Quila in Delhi on 7th Oct. 1556 as a 'Vikramaditya' king. Hemu lost his life in the Second Battle of Panipat on 5 November 1556, and the area came under Mughal king Akbar.";
        public static string SampleParagraph4 = "Near the beginning of his career, Einstein thought that Newtonian mechanics was no longer enough to reconcile the laws of classical mechanics with the laws of the electromagnetic field. This led to the development of his special theory of relativity. He realized, however, that the principle of relativity could also be extended to gravitational fields, and with his subsequent theory of gravitation in 1916, he published a paper on the general theory of relativity. He continued to deal with problems of statistical mechanics and quantum theory, which led to his explanations of particle theory and the motion of molecules. He also investigated the thermal properties of light which laid the foundation of the photon theory of light. In 1917, Einstein applied the general theory of relativity to model the large-scale structure of the universe. He was visiting the United States when Adolf Hitler came to power in 1933 and did not go back to Germany, where he had been a professor at the Berlin Academy of Sciences. He settled in the U.S., becoming an American citizen in 1940. On the eve of World War II, he endorsed a letter to President Franklin D. Roosevelt alerting him to the potential development of \"extremely powerful bombs of a new type\" and recommending that the U.S. begin similar research. This eventually led to what would become the Manhattan Project. Einstein supported defending the Allied forces, but largely denounced using the new discovery of nuclear fission as a weapon. Later, with the British philosopher Bertrand Russell, Einstein signed the Russell–Einstein Manifesto, which highlighted the danger of nuclear weapons. Einstein was affiliated with the Institute for Advanced Study in Princeton, New Jersey, until his death in 1955. Einstein published more than 300 scientific papers along with over 150 non-scientific works.";
        public static string SampleParagraph5 = "Kingfishers are a group of small to medium sized brightly coloured birds in the order Coraciiformes. They have a cosmopolitan distribution, with most species found outside of the Americas. The group is treated either as a single family, Alcedinidae, or as a suborder Alcedines containing three families, Alcedinidae (river kingfishers), Halcyonidae (tree kingfishers), and Cerylidae (water kingfishers). There are roughly 90 species of kingfisher. All have large heads, long, sharp, pointed bills, short legs, and stubby tails. Most species have bright plumage with little differences between the sexes. Most species are tropical in distribution, and a slight majority are found only in forests. They consume a wide range of prey as well as fish, usually caught by swooping down from a perch. Like other members of their order they nest in cavities, usually tunnels dug into the natural or artificial banks in the ground. A few species, principally insular forms, are threatened with extinction. In Britain, the word 'kingfisher' normally refers to the Common Kingfisher. The taxonomy of the three families is complex and rather controversial. Although commonly assigned to the order Coraciiformes, from this level down confusion sets in. The kingfishers were traditionally treated as one family, Alcedinidae with three subfamilies, but following the 1990s revolution in bird taxonomy, the three former subfamilies are now often elevated to familial level. That move was supported by chromosome and DNA–DNA hybridisation studies, but challenged on the grounds that all three groups are monophyletic with respect to the other Coraciiformes. This leads to them being grouped as the suborder Alcedines. The tree kingfishers have been previously given the familial name Dacelonidae but Halcyonidae has priority. The centre of kingfisher diversity is the Australasian region, but the group is not thought to have originated there. Instead, they evolved in the Northern Hemisphere and invaded the Australasian region a number of times.[1] Fossil kingfishers have been described from Lower Eocene rocks in Wyoming and Middle Eocene rocks in Germany, around 30–40 million years ago. More recent fossil kingfishers have been described in the Miocene rocks of Australia (5–25 million years old). Several fossil birds have been erroneously ascribed to the kingfishers, including Halcyornis, from the Lower Eocene rocks in Kent, which has also been considered a gull, but is now thought to have been a member of an extinct family.";

        public static List<string> GetQuestions1()
        {
            return new List<string>{
                "Which Zebras are endangered?",
                "What is the aim of the Quagga Project?",
                "Which animals are some of their closest relatives?",
                "Which are the three species of zebras?",
                "Which subgenus do the plains zebra and the mountain zebra belong to?"
            };
        }

        public static List<string> GetQuestions2()
        {
            return new List<string>{
                "When did the Welsh national identity emerge among the Celtic Britons?",
                "What was Welsh Liberalism displaced by?",
                "How much of the population lives in south Wales?",
                "What does Wales' economy now depend on?",
                "When was Plaid Cymru formed?"
            };
        }

        public static List<string> GetQuestions3()
        {
            return new List<string>{
                "Which is the second largest city in the Indian state of Rajasthan?",
                "Why is Jodhpur known as the \"Sun City\"?",
                "Why is Jodhpur known as the \"Blue City\"?",
                "According to Rajasthan district Gazetteers of Jodhpur and the Hindu epic Ramayana, who were the original inhabitants of Jodhpur?",
                "When did Hemu lose his life?"
            };
        }

        public static List<string> GetQuestions4()
        {
            return new List<string> {
                "When did Einstein apply the general theory of relativity to model the large-scale structure of the universe?",
                "What does the Russell–Einstein Manifesto highlight?",
                "How many scientific papers did Einstein publish?",
                "Which institute in New Jersey was Einstein affiliated with?",
                "What did Einstein realize, the principle of relativity could be extended to?"
            };
        }

        public static List<string> GetQuestions5()
        {
            return new List<string> {
                "In which order are Kingfishers?",
                "Which birds have been have been erroneously ascribed to the kingfishers?",
                "In Britain, what does the word 'kingfisher' normally refer to?",
                "How are fish usually caught by Kingfishers?",
                "In which suborder are Kingfishers now grouped?"
            };
        }

        public static Dictionary<string, string> GetResults1()
        {
            var results = new Dictionary<string, string>();
            results["Grevy's zebra and the mountain zebra"] = "Which Zebras are endangered?";
            results["aims to breed zebras that are phenotypically similar to the quagga"] = "What is the aim of the Quagga Project?";
            results["horses and donkeys"] = "Which animals are some of their closest relatives?";
            results["the plains zebra, the Grevy's zebra and the mountain zebra"] = "Which are the three species of zebras?";
            results["subgenus Hippotigris"] = "Which subgenus do the plains zebra and the mountain zebra belong to?";
            return results;
        }

        public static Dictionary<string, string> GetResults2()
        {
            var results = new Dictionary<string, string>();
            results["after the Roman withdrawal from Britain in the 5th century"] = "When did the Welsh national identity emerge among the Celtic Britons?";
            results["the growth of socialism and the Labour Party"] = "What was Welsh Liberalism displaced by?";
            results["Two-thirds"] = "How much of the population lives in south Wales?";
            results["the public sector, light and service industries and tourism"] = "What does Wales' economy now depend on?";
            results["1925"] = "When was Plaid Cymru formed?";
            return results;
        }

        public static Dictionary<string, string> GetResults3()
        {
            var results = new Dictionary<string, string>();
            results["due to the vivid blue-painted houses around the Mehrangarh Fort"] = "Why is Jodhpur known as the \"Blue City\"?";
            results["Jodhpur"] = "Which is the second largest city in the Indian state of Rajasthan?";
            results["for the bright, sunny weather it enjoys all the year round"] = "Why is Jodhpur known as the \"Sun City\"?";
            results["Abhiras (Ahirs)"] = "According to Rajasthan district Gazetteers of Jodhpur and the Hindu epic Ramayana, who were the original inhabitants of Jodhpur?";
            results["5 November 1556"] = "When did Hemu lose his life?";
            return results;
        }

        public static Dictionary<string, string> GetResults4()
        {
            var results = new Dictionary<string, string>();
            results["the danger of nuclear weapons"] = "What does the Russell–Einstein Manifesto highlight?";
            results["more than 300 scientific papers"] = "How many scientific papers did Einstein publish?";
            results["principle of relativity could also be extended to gravitational fields"] = "What did Einstein realize, the principle of relativity could be extended to?";
            results["1917"] = "When did Einstein apply the general theory of relativity to model the large-scale structure of the universe?";
            results["Institute for Advanced Study in Princeton"] = "Which institute in New Jersey was Einstein affiliated with?";
            return results;
        }

        public static Dictionary<string, string> GetResults5()
        {
            var results = new Dictionary<string, string>();
            results["Common Kingfisher"] = "In Britain, what does the word 'kingfisher' normally refer to?";
            results["by swooping down from a perch"] = "How are fish usually caught by Kingfishers?";
            results["Alcedines"] = "In which suborder are Kingfishers now grouped?";
            results["Coraciiformes"] = "In which order are Kingfishers?";
            results["Several fossil birds"] = "Which birds have been have been erroneously ascribed to the kingfishers?";
            return results;
        }
    }
}
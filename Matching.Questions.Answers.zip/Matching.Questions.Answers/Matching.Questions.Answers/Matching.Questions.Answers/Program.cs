﻿namespace Matching.Questions.Answers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Matching.Questions.Answers.Extensions;
    using Matching.Questions.Answers.Utils;

    /// <summary>
    /// Class for console app entry point.
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// Program entry.
        /// </summary>
        /// <param name="args">The arguments.</param>
        public static void Main(string[] args)
        {
            string paragraph = ConsoleUtil.ReadLine();
            IList<string> questions = new List<string>(5);
            for (int i = 0; i < 5; i++)
            {
                var question = Console.ReadLine();
                questions.Insert(i, question);
            }
            // Clone questions as the orignal list of question will be empty after mapping.
            var clonedCopyOfQuestions = questions.Clone();
            string answersForAllQuestions = Console.ReadLine();
            IDictionary<string, string> mappedAnswersAndQuestions
                = MatchQuestionAndAnswer(paragraph, questions, answersForAllQuestions);
            PrintAnswers(clonedCopyOfQuestions, mappedAnswersAndQuestions);
            Console.ReadLine();
        }

        /// <summary>
        /// Matches the question and answer.
        /// </summary>
        /// <param name="paragraph">The paragraph.</param>
        /// <param name="questions">The questions.</param>
        /// <param name="answersForAllQuestions">The answers for all questions.</param>
        /// <returns>Matched questions and answers.</returns>
        private static IDictionary<string, string> MatchQuestionAndAnswer(
            string paragraph,
            IList<string> questions,
            string answersForAllQuestions)
        {
            Matcher matcher = new Matcher(paragraph, questions, answersForAllQuestions);
            IDictionary<string, string> mappedAnswersAndQuestions = matcher.Match();
            return mappedAnswersAndQuestions;
        }

        /// <summary>
        /// Prints the answers.
        /// </summary>
        /// <param name="questions">The questions.</param>
        /// <param name="mappedAnswersAndQuestions">The mapped answers and questions.</param>
        private static void PrintAnswers(
            IList<string> questions,
            IDictionary<string, string> mappedAnswersAndQuestions)
        {
            IDictionary<string, string> questionAndAnswers
                = mappedAnswersAndQuestions
                    .ToLookup(kvp => kvp.Value)
                    .ToDictionary(item => item.Key, g => g.First().Key); // Handle duplicates
            foreach (var key in questions)
            {
                Console.WriteLine(questionAndAnswers[key]);
            }
        }
    }
}
﻿namespace Matching.Questions.Answers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Matching.Questions.Answers.Extensions;
    using Matching.Questions.Answers.Interfaces;
    using Matching.Questions.Answers.Utils;

    /// <summary>
    /// Matching implementation.
    /// </summary>
    public class Matcher
    {
        /// <summary>
        /// The matching strategy
        /// </summary>
        private IMatchingStrategy _matchingStrategy;

        /// <summary>
        /// Initializes a new instance of the <see cref="Matcher"/> class.
        /// </summary>
        /// <param name="paragraph">The paragraph.</param>
        /// <param name="questions">The questions.</param>
        /// <param name="answersForAllQuestions">The answers for all questions.</param>
        /// <exception cref="System.ArgumentNullException">
        /// paragraph
        /// or
        /// questions
        /// or
        /// answersForAllQuestions
        /// </exception>
        public Matcher(string paragraph, IList<string> questions, string answersForAllQuestions)
        {
            if (string.IsNullOrWhiteSpace(paragraph) || paragraph.Length > 5000)
            {
                throw new ArgumentNullException("paragraph");
            }

            if (null == questions || questions.Count == 0)
            {
                throw new ArgumentNullException("questions");
            }

            if (string.IsNullOrWhiteSpace(answersForAllQuestions))
            {
                throw new ArgumentNullException("answersForAllQuestions");
            }

            Paragraph = paragraph;
            Sentences = GetSentences(paragraph);
            Questions = questions;
            Answers = GetAnswers(questions.Count, answersForAllQuestions);
        }

        /// <summary>
        /// Gets the answers.
        /// </summary>
        /// <value>
        /// The answers.
        /// </value>
        public string[] Answers { get; private set; }

        /// <summary>
        /// Gets the matching strategy.
        /// </summary>
        /// <value>
        /// The matching strategy for matching keywords and sentences.
        /// </value>
        public IMatchingStrategy MatchingStrategy
        {
            get
            {
                if (null == _matchingStrategy)
                {
                    // Use DI - constructor or property injection for much complex projects.
                    // Considering this simple sample - going ahead with direct instantiation.
                    _matchingStrategy = new MatchingStrategy();
                }

                return _matchingStrategy;
            }
        }

        /// <summary>
        /// Gets the paragraph.
        /// </summary>
        /// <value>
        /// The paragraph.
        /// </value>
        public string Paragraph { get; private set; }

        /// <summary>
        /// Gets the questions.
        /// </summary>
        /// <value>
        /// The questions.
        /// </value>
        public IList<string> Questions { get; private set; }

        /// <summary>
        /// Gets the sentences.
        /// </summary>
        /// <value>
        /// The sentences.
        /// </value>
        public string[] Sentences { get; private set; }

        /// <summary>
        /// Matches questions and answers.
        /// </summary>
        /// <returns>Matched questions and answers.</returns>
        public IDictionary<string, string> Match()
        {
            IDictionary<string, IList<string>> answersAndMatchingSentences
                = DetermineSentencesContainingAnswer();
            // Sort the answersAndMatchingSentences by least number of matching sentences.
            answersAndMatchingSentences
                = answersAndMatchingSentences.SortByNumberOfElements();
            IDictionary<string, string> matchedAnswersAndQuestions
                = DetermineQuestionAndAnswer(answersAndMatchingSentences);
            return matchedAnswersAndQuestions;
        }

        /// <summary>
        /// Get the individual answers from the string delimited by semi-colon.
        /// </summary>
        /// <param name="numberOfQuestions">Number of questions</param>
        /// <param name="answersForAllQuestions">Answers with semi-colon delimiter.</param>
        /// <returns>
        /// Array of answers
        /// </returns>
        private static string[] GetAnswers(int numberOfQuestions, string answersForAllQuestions)
        {
            return answersForAllQuestions.Split(new char[] { ';' },
                                                    numberOfQuestions,
                                                    StringSplitOptions.RemoveEmptyEntries);
        }

        /// <summary>
        /// Gets the sentences.
        /// </summary>
        /// <param name="paragraph">The paragraph.</param>
        /// <returns>Sentences in teh paragraph.</returns>
        private static string[] GetSentences(string paragraph)
        {
            string[] sentences = paragraph.Split(new char[] { '?', '!', '.' }, StringSplitOptions.RemoveEmptyEntries);
            return sentences;
        }

        /// <summary>
        /// Determines the question and answer.
        /// </summary>
        /// <param name="answersAndMatchingSentences">The answers and matching sentences.</param>
        /// <returns>Matched answers and questions.</returns>
        private IDictionary<string, string> DetermineQuestionAndAnswer(
            IDictionary<string,
            IList<string>> answersAndMatchingSentences)
        {
            IDictionary<string, string> matchedAnswersAndQuestions = new Dictionary<string, string>();
            foreach (var answer in answersAndMatchingSentences.Keys)
            {
                matchedAnswersAndQuestions[answer]
                    = GetBestPossibleQuestion(answersAndMatchingSentences[answer]);
            }

            return matchedAnswersAndQuestions;
        }

        /// <summary>
        /// Determines the sentences containing answer.
        /// </summary>
        /// <returns>Map of answers and sentences.</returns>
        private IDictionary<string, IList<string>> DetermineSentencesContainingAnswer()
        {
            IDictionary<string, IList<string>> answersAndMatchingSentences
                = new Dictionary<string, IList<string>>();
            foreach (var answer in Answers)
            {
                IList<string> sentencesContainingAnswer = GetMatchingSentencesContainingAnswer(answer);
                answersAndMatchingSentences[answer] = sentencesContainingAnswer;
            }
            return answersAndMatchingSentences;
        }

        /// <summary>
        /// Gets the best possible question.
        /// </summary>
        /// <param name="sentencesContainingAnswer">The sentences containing answer.</param>
        /// <returns>Best possible question for given answer.</returns>
        private string GetBestPossibleQuestion(IList<string> sentencesContainingAnswer)
        {
            // NOTES -> SELF: If count is more than one, we need to process both the
            // sentences and choose the question with best pattern match.
            // Since answer is a substring of sentences in the passage, the probability
            // is slightly less, that said, case of more than one matching sentence
            // per answer cannot be completely ruled out.
            IDictionary<int, int> bestPossibleMatches = new Dictionary<int, int>();
            foreach (var sentence in sentencesContainingAnswer)
            {
                string[] keywordsInSentence = LanguageUtils.RemoveStopWords(sentence);
                IDictionary<int, int> possibleMatches = GetPossibleMatches(keywordsInSentence);

                // Update best possible match
                foreach (var key in possibleMatches.Keys)
                {
                    var value = possibleMatches[key];
                    if (!bestPossibleMatches.ContainsKey(key) || value > bestPossibleMatches[key])
                    {
                        bestPossibleMatches[key] = value;
                    }
                }
            }

            var bestQuestionIndex
                = bestPossibleMatches.Aggregate((left, right) => left.Value > right.Value ? left : right).Key;
            string question = Questions[bestQuestionIndex];
            // Remove - as this question is chosen!
            Questions.RemoveAt(bestQuestionIndex);
            return question;
        }

        /// <summary>
        /// Gets the matching sentences containing answer.
        /// </summary>
        /// <param name="answer">The answer.</param>
        /// <returns>Matching sentences.</returns>
        private IList<string> GetMatchingSentencesContainingAnswer(string answer)
        {
            var matchingSentences = Sentences.Where(sentense => sentense.Contains(answer)).ToList();
            return matchingSentences;
        }

        /// <summary>
        /// Gets the possible matches.
        /// </summary>
        /// <param name="keywordsInSentence">The keywords in sentence.</param>
        /// <returns>Possible matches.</returns>
        private IDictionary<int, int> GetPossibleMatches(string[] keywordsInSentence)
        {
            IDictionary<int, int> possibleMatches = new Dictionary<int, int>();
            for (int i = 0; i < Questions.Count; i++)
            {
                string question = Questions[i];
                string[] keywordsInQuestion = LanguageUtils.RemoveStopWords(question);
                int numberOfMatches = MatchingStrategy.GetNumberofMatchingKeywords(keywordsInSentence, keywordsInQuestion);
                possibleMatches[i] = numberOfMatches;
            }

            return possibleMatches;
        }
    }
}
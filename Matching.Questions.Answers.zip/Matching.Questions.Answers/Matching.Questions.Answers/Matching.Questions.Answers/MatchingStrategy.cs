﻿namespace Matching.Questions.Answers
{
    using Matching.Questions.Answers.Interfaces;

    public class MatchingStrategy : IMatchingStrategy
    {
        /// <summary>
        /// Gets the numberof matching keywords.
        /// </summary>
        /// <param name="keywordsInSentence">The keywords in sentence.</param>
        /// <param name="keywordsInQuestion">The keywords in question.</param>
        /// <returns>
        /// Number of matching keywords.
        /// </returns>
        public int GetNumberofMatchingKeywords(string[] keywordsInSentence, string[] keywordsInQuestion)
        {
            int count = 0;
            // Check if there is partial match between keywords!
            for (int i = 0; i < keywordsInQuestion.Length; i++)
            {
                for (int j = 0; j < keywordsInSentence.Length; j++)
                {
                    if (keywordsInQuestion[i].Contains(keywordsInSentence[j])
                        || keywordsInSentence[j].Contains(keywordsInQuestion[i]))
                    {
                        count++;
                    }
                }
            }

            return count;
        }
    }
}
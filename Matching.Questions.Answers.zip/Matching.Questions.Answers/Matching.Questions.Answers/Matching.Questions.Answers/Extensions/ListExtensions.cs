﻿namespace Matching.Questions.Answers.Extensions
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    /// <summary>
    /// Extension functions for generic list.
    /// </summary>
    public static class ListExtensions
    {
        /// <summary>
        /// Clones the specified list to clone.
        /// </summary>
        /// <typeparam name="T">Type.</typeparam>
        /// <param name="listToClone">The list to clone.</param>
        /// <returns>Cloned copy of list.</returns>
        public static IList<T> Clone<T>(this IList<T> listToClone) where T : ICloneable
        {
            return listToClone.Select(item => (T)item.Clone()).ToList();
        }
    }
}
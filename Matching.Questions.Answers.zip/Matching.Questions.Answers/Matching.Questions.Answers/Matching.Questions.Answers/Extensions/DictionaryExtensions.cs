﻿namespace Matching.Questions.Answers.Extensions
{
    using System.Collections.Generic;
    using System.Linq;

    /// <summary>
    /// Extension methods for Generic Dictionary
    /// </summary>
    public static class DictionaryExtensions
    {
        /// <summary>
        /// Sorts the by number of elements.
        /// </summary>
        /// <typeparam name="T">Type</typeparam>
        /// <param name="input">The input dictionary.</param>
        /// <returns>Dictionary with sorted elements.</returns>
        public static IDictionary<T, IList<T>> SortByNumberOfElements<T>(this IDictionary<T, IList<T>> input)
        {
            var result = new Dictionary<T, IList<T>>();
            var sortedInput = from pair in input
                              orderby pair.Value.Count ascending
                              select pair;

            foreach (var keyValuePair in sortedInput)
            {
                result[keyValuePair.Key] = keyValuePair.Value;
            }

            return result;
        }
    }
}
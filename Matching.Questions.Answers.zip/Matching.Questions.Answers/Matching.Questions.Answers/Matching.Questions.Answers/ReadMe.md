﻿#Matching Question and Answers
## Solution Description ##
The problem states that answers are exact sub-string of sentences in the paragraph, and that answers could be one word, group of words, or a complete sentence.

### Steps - In Short: ###
1. Start from the answer and determine the best possible question.
2. Determine the matching sentences for a given answer.
3. There is a possibility of more than one sentence containing the answer. Process the answers with least number of matching sentences first.
4.  For each matching sentence, start comparing the keywords in the sentence with question. The question with best possible match is select as the best possible question.

######Srihari Sridharan######
﻿namespace Matching.Questions.Answers.Interfaces
{
    public interface IMatchingStrategy
    {
        /// <summary>
        /// Gets the numberof matching keywords.
        /// </summary>
        /// <param name="keywordsInSentence">The keywords in sentence.</param>
        /// <param name="keywordsInQuestion">The keywords in question.</param>
        /// <returns>Number of matching keywords.</returns>
        int GetNumberofMatchingKeywords(string[] keywordsInSentence, string[] keywordsInQuestion);
    }
}
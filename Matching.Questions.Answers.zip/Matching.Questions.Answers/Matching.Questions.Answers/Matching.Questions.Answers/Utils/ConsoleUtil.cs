﻿namespace Matching.Questions.Answers.Utils
{
    using System;
    using System.IO;
    using System.Text;

    /// <summary>
    /// Console utility functions to support data entry.
    /// </summary>
    public static class ConsoleUtil
    {
        /// <summary>
        /// READLINE_BUFFER_SIZE
        /// </summary>
        public const int READLINE_BUFFER_SIZE = 5000;

        /// <summary>
        /// Reads a line of input from console.
        /// </summary>
        /// <returns>String representation of console input.</returns>
        public static string ReadLine()
        {
            Stream inputStream = Console.OpenStandardInput(READLINE_BUFFER_SIZE);
            byte[] bytes = new byte[READLINE_BUFFER_SIZE];
            int outputLength = inputStream.Read(bytes, 0, READLINE_BUFFER_SIZE);
            char[] chars = Encoding.UTF8.GetChars(bytes, 0, outputLength);
            return new string(chars);
        }
    }
}